public class Solver {
	public static void main (String [ ] args) {
		return;
	}
}
