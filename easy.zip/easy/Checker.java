public class Checker {
	public static void main (String [ ] args) {
		return;
	}
}
